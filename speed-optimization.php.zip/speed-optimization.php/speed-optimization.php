<?php
/**
 * Plugin Name: Speed Optimization WP6
 * Description: Ubrzava učitavanje stranica optimiziranjem resursa za WordPress 6.
 * Version: 1.0
 * Author: bz
 */

function enable_page_cache() {
    header('Cache-Control: max-age=31536000');
}
add_action('send_headers', 'enable_page_cache');

function minify_html($buffer) {
    return preg_replace(['/>\s+</', '/\s{2,}/'], ['><', ' '], $buffer);
}
ob_start('minify_html');

function async_css($tag, $handle) {
    if (!is_admin()) {
        return str_replace("rel='stylesheet'", "rel='stylesheet' media='print' onload='this.media=\"all\"'", $tag);
    }
    return $tag;
}
add_filter('style_loader_tag', 'async_css', 10, 2);
?>
